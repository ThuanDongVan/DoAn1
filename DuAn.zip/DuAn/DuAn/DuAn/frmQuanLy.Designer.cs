﻿namespace DuAn
{
    partial class frmQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tcQuanLy = new System.Windows.Forms.TabControl();
            this.tpQLTK = new System.Windows.Forms.TabPage();
            this.cbVaiTro = new System.Windows.Forms.ComboBox();
            this.dtNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.dgvTaiKhoan = new System.Windows.Forms.DataGridView();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VaiTro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tpQLDG = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTimKiemDG = new System.Windows.Forms.TextBox();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.MaDG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTenDG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTimKiemDG = new System.Windows.Forms.Button();
            this.btnXoaDG = new System.Windows.Forms.Button();
            this.btnSuaDG = new System.Windows.Forms.Button();
            this.btnThemDG = new System.Windows.Forms.Button();
            this.txtDiaChiDG = new System.Windows.Forms.TextBox();
            this.txtSDTDG = new System.Windows.Forms.TextBox();
            this.txtEmailDG = new System.Windows.Forms.TextBox();
            this.dtNgaySinhDG = new System.Windows.Forms.DateTimePicker();
            this.txtMaDG = new System.Windows.Forms.TextBox();
            this.txtHoTenDG = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tpQLS = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtNXB = new System.Windows.Forms.TextBox();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtTKS = new System.Windows.Forms.TextBox();
            this.dgvQLSach = new System.Windows.Forms.DataGridView();
            this.btnTKS = new System.Windows.Forms.Button();
            this.btnXoaS = new System.Windows.Forms.Button();
            this.btnSuaS = new System.Windows.Forms.Button();
            this.btnThemS = new System.Windows.Forms.Button();
            this.txtGiaS = new System.Windows.Forms.TextBox();
            this.txtMaTLS = new System.Windows.Forms.TextBox();
            this.txtTinhTrangS = new System.Windows.Forms.TextBox();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.txtMaS = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tpQLTL = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.txtTKTL = new System.Windows.Forms.TextBox();
            this.dgvTheLoai = new System.Windows.Forms.DataGridView();
            this.MaTL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenTL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTKTL = new System.Windows.Forms.Button();
            this.btnXoaTL = new System.Windows.Forms.Button();
            this.btnSuaTL = new System.Windows.Forms.Button();
            this.btnThemTL = new System.Windows.Forms.Button();
            this.txtTenTL = new System.Windows.Forms.TextBox();
            this.txtMaTL = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.tpQLPMT = new System.Windows.Forms.TabPage();
            this.txtMaDGPMT = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtTKPMT = new System.Windows.Forms.TextBox();
            this.btnTKPMT = new System.Windows.Forms.Button();
            this.btnXoaPMT = new System.Windows.Forms.Button();
            this.btnSuaPMT = new System.Windows.Forms.Button();
            this.btnThemPMT = new System.Windows.Forms.Button();
            this.dgvMuonTra = new System.Windows.Forms.DataGridView();
            this.MaPM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaDGPMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayMuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtNgayMuon = new System.Windows.Forms.DateTimePicker();
            this.txtMaPM = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.tpQLCTPMPT = new System.Windows.Forms.TabPage();
            this.txtPhieuMuonCTPMT = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtMaSachCTPMT = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.dgvQLCTPMT = new System.Windows.Forms.DataGridView();
            this.MaCTPMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaSachCTPMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaPMCTPMT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayTra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TienPhat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTKCTPMT = new System.Windows.Forms.TextBox();
            this.btnTKCTPMT = new System.Windows.Forms.Button();
            this.btnXoaCTPMT = new System.Windows.Forms.Button();
            this.btnSuaCTPMT = new System.Windows.Forms.Button();
            this.btnThemCTPMT = new System.Windows.Forms.Button();
            this.dtNgayTra = new System.Windows.Forms.DateTimePicker();
            this.txtTinhTrangCTPMT = new System.Windows.Forms.TextBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.txtTienPhat = new System.Windows.Forms.TextBox();
            this.txtMaCTPM = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.MaSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTLS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TacGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NamXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtNamXB = new System.Windows.Forms.TextBox();
            this.tcQuanLy.SuspendLayout();
            this.tpQLTK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaiKhoan)).BeginInit();
            this.tpQLDG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.tpQLS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLSach)).BeginInit();
            this.tpQLTL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheLoai)).BeginInit();
            this.tpQLPMT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMuonTra)).BeginInit();
            this.tpQLCTPMPT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLCTPMT)).BeginInit();
            this.SuspendLayout();
            // 
            // tcQuanLy
            // 
            this.tcQuanLy.Controls.Add(this.tpQLTK);
            this.tcQuanLy.Controls.Add(this.tpQLDG);
            this.tcQuanLy.Controls.Add(this.tpQLS);
            this.tcQuanLy.Controls.Add(this.tpQLTL);
            this.tcQuanLy.Controls.Add(this.tpQLPMT);
            this.tcQuanLy.Controls.Add(this.tpQLCTPMPT);
            this.tcQuanLy.Location = new System.Drawing.Point(12, 12);
            this.tcQuanLy.Name = "tcQuanLy";
            this.tcQuanLy.SelectedIndex = 0;
            this.tcQuanLy.Size = new System.Drawing.Size(1157, 492);
            this.tcQuanLy.TabIndex = 1;
            // 
            // tpQLTK
            // 
            this.tpQLTK.Controls.Add(this.cbVaiTro);
            this.tpQLTK.Controls.Add(this.dtNgaySinh);
            this.tpQLTK.Controls.Add(this.txtEmail);
            this.tpQLTK.Controls.Add(this.txtDiaChi);
            this.tpQLTK.Controls.Add(this.label8);
            this.tpQLTK.Controls.Add(this.label9);
            this.tpQLTK.Controls.Add(this.txtSDT);
            this.tpQLTK.Controls.Add(this.label6);
            this.tpQLTK.Controls.Add(this.label7);
            this.tpQLTK.Controls.Add(this.txtHoTen);
            this.tpQLTK.Controls.Add(this.label4);
            this.tpQLTK.Controls.Add(this.label5);
            this.tpQLTK.Controls.Add(this.label3);
            this.tpQLTK.Controls.Add(this.btnXoa);
            this.tpQLTK.Controls.Add(this.btnSua);
            this.tpQLTK.Controls.Add(this.dgvTaiKhoan);
            this.tpQLTK.Controls.Add(this.btnThem);
            this.tpQLTK.Controls.Add(this.txtPassword);
            this.tpQLTK.Controls.Add(this.txtUsername);
            this.tpQLTK.Controls.Add(this.label2);
            this.tpQLTK.Controls.Add(this.label1);
            this.tpQLTK.Location = new System.Drawing.Point(4, 25);
            this.tpQLTK.Name = "tpQLTK";
            this.tpQLTK.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLTK.Size = new System.Drawing.Size(1149, 463);
            this.tpQLTK.TabIndex = 0;
            this.tpQLTK.Text = "Quản lý tài khoản";
            this.tpQLTK.UseVisualStyleBackColor = true;
            // 
            // cbVaiTro
            // 
            this.cbVaiTro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbVaiTro.FormattingEnabled = true;
            this.cbVaiTro.Location = new System.Drawing.Point(380, 149);
            this.cbVaiTro.Name = "cbVaiTro";
            this.cbVaiTro.Size = new System.Drawing.Size(172, 24);
            this.cbVaiTro.TabIndex = 29;
            // 
            // dtNgaySinh
            // 
            this.dtNgaySinh.CustomFormat = "dd/MM/yyyy";
            this.dtNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgaySinh.Location = new System.Drawing.Point(650, 84);
            this.dtNgaySinh.Name = "dtNgaySinh";
            this.dtNgaySinh.Size = new System.Drawing.Size(180, 22);
            this.dtNgaySinh.TabIndex = 26;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(935, 146);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(179, 22);
            this.txtEmail.TabIndex = 32;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(935, 86);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(179, 22);
            this.txtDiaChi.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(874, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 17);
            this.label8.TabIndex = 42;
            this.label8.Text = "Email:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(874, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 17);
            this.label9.TabIndex = 41;
            this.label9.Text = "Địa chỉ:";
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(650, 146);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(180, 22);
            this.txtSDT.TabIndex = 30;
            this.txtSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDT_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(569, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 17);
            this.label6.TabIndex = 40;
            this.label6.Text = "SDT:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(569, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 17);
            this.label7.TabIndex = 39;
            this.label7.Text = "Ngày sinh:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(380, 86);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(172, 22);
            this.txtHoTen.TabIndex = 25;
            this.txtHoTen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHoTen_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(316, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 38;
            this.label4.Text = "Vai trò:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(316, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 37;
            this.label5.Text = "Họ tên: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(458, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 24);
            this.label3.TabIndex = 36;
            this.label3.Text = "QUẢN LÝ TÀI KHOẢN";
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(800, 218);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(79, 31);
            this.btnXoa.TabIndex = 35;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(530, 218);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(79, 31);
            this.btnSua.TabIndex = 34;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // dgvTaiKhoan
            // 
            this.dgvTaiKhoan.AllowUserToAddRows = false;
            this.dgvTaiKhoan.AllowUserToDeleteRows = false;
            this.dgvTaiKhoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTaiKhoan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Username,
            this.Password,
            this.HoTenNV,
            this.VaiTro,
            this.NgaySinh,
            this.SDT,
            this.DiaChi,
            this.Email});
            this.dgvTaiKhoan.Location = new System.Drawing.Point(56, 284);
            this.dgvTaiKhoan.Name = "dgvTaiKhoan";
            this.dgvTaiKhoan.RowTemplate.Height = 24;
            this.dgvTaiKhoan.Size = new System.Drawing.Size(1058, 150);
            this.dgvTaiKhoan.TabIndex = 31;
            this.dgvTaiKhoan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTaiKhoan_CellClick);
            // 
            // Username
            // 
            this.Username.DataPropertyName = "Username";
            this.Username.HeaderText = "Username";
            this.Username.Name = "Username";
            // 
            // Password
            // 
            this.Password.DataPropertyName = "Password";
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            // 
            // HoTenNV
            // 
            this.HoTenNV.DataPropertyName = "HoTenNV";
            this.HoTenNV.HeaderText = "Họ tên";
            this.HoTenNV.Name = "HoTenNV";
            // 
            // VaiTro
            // 
            this.VaiTro.DataPropertyName = "VaiTro";
            this.VaiTro.HeaderText = "Vai trò";
            this.VaiTro.Name = "VaiTro";
            // 
            // NgaySinh
            // 
            this.NgaySinh.DataPropertyName = "NgaySinh";
            this.NgaySinh.HeaderText = "Ngày sinh";
            this.NgaySinh.Name = "NgaySinh";
            // 
            // SDT
            // 
            this.SDT.DataPropertyName = "SDT";
            this.SDT.HeaderText = "SDT";
            this.SDT.Name = "SDT";
            // 
            // DiaChi
            // 
            this.DiaChi.DataPropertyName = "DiaChi";
            this.DiaChi.HeaderText = "Địa chỉ";
            this.DiaChi.Name = "DiaChi";
            // 
            // Email
            // 
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(255, 218);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(79, 31);
            this.btnThem.TabIndex = 33;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click_1);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(113, 146);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(174, 22);
            this.txtPassword.TabIndex = 28;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(117, 86);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(170, 22);
            this.txtUsername.TabIndex = 23;
            this.txtUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 24;
            this.label2.Text = "Password:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 22;
            this.label1.Text = "Username:";
            // 
            // tpQLDG
            // 
            this.tpQLDG.Controls.Add(this.label10);
            this.tpQLDG.Controls.Add(this.txtTimKiemDG);
            this.tpQLDG.Controls.Add(this.dgvDocGia);
            this.tpQLDG.Controls.Add(this.btnTimKiemDG);
            this.tpQLDG.Controls.Add(this.btnXoaDG);
            this.tpQLDG.Controls.Add(this.btnSuaDG);
            this.tpQLDG.Controls.Add(this.btnThemDG);
            this.tpQLDG.Controls.Add(this.txtDiaChiDG);
            this.tpQLDG.Controls.Add(this.txtSDTDG);
            this.tpQLDG.Controls.Add(this.txtEmailDG);
            this.tpQLDG.Controls.Add(this.dtNgaySinhDG);
            this.tpQLDG.Controls.Add(this.txtMaDG);
            this.tpQLDG.Controls.Add(this.txtHoTenDG);
            this.tpQLDG.Controls.Add(this.label11);
            this.tpQLDG.Controls.Add(this.label12);
            this.tpQLDG.Controls.Add(this.label13);
            this.tpQLDG.Controls.Add(this.label14);
            this.tpQLDG.Controls.Add(this.label15);
            this.tpQLDG.Controls.Add(this.label16);
            this.tpQLDG.Location = new System.Drawing.Point(4, 25);
            this.tpQLDG.Name = "tpQLDG";
            this.tpQLDG.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLDG.Size = new System.Drawing.Size(1149, 463);
            this.tpQLDG.TabIndex = 1;
            this.tpQLDG.Text = "Quản lý độc giả";
            this.tpQLDG.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(470, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(189, 24);
            this.label10.TabIndex = 38;
            this.label10.Text = "QUẢN LÝ ĐỘC GIẢ";
            // 
            // txtTimKiemDG
            // 
            this.txtTimKiemDG.Location = new System.Drawing.Point(826, 205);
            this.txtTimKiemDG.Name = "txtTimKiemDG";
            this.txtTimKiemDG.Size = new System.Drawing.Size(192, 22);
            this.txtTimKiemDG.TabIndex = 37;
            // 
            // dgvDocGia
            // 
            this.dgvDocGia.AllowUserToAddRows = false;
            this.dgvDocGia.AllowUserToDeleteRows = false;
            this.dgvDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDocGia.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaDG,
            this.HoTenDG,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dgvDocGia.Location = new System.Drawing.Point(160, 256);
            this.dgvDocGia.Name = "dgvDocGia";
            this.dgvDocGia.ReadOnly = true;
            this.dgvDocGia.RowTemplate.Height = 24;
            this.dgvDocGia.Size = new System.Drawing.Size(857, 150);
            this.dgvDocGia.TabIndex = 36;
            this.dgvDocGia.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDocGia_CellClick);
            // 
            // MaDG
            // 
            this.MaDG.DataPropertyName = "MaDG";
            this.MaDG.HeaderText = "Mã độc giả";
            this.MaDG.Name = "MaDG";
            this.MaDG.ReadOnly = true;
            // 
            // HoTenDG
            // 
            this.HoTenDG.DataPropertyName = "HoTenDG";
            this.HoTenDG.HeaderText = "Họ tên độc giả";
            this.HoTenDG.Name = "HoTenDG";
            this.HoTenDG.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NgaySinh";
            this.dataGridViewTextBoxColumn1.HeaderText = "Ngày sinh";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn2.HeaderText = "Email";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DiaChi";
            this.dataGridViewTextBoxColumn3.HeaderText = "Địa chỉ";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "SDT";
            this.dataGridViewTextBoxColumn4.HeaderText = "Số điện thoại";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // btnTimKiemDG
            // 
            this.btnTimKiemDG.Location = new System.Drawing.Point(727, 200);
            this.btnTimKiemDG.Name = "btnTimKiemDG";
            this.btnTimKiemDG.Size = new System.Drawing.Size(93, 33);
            this.btnTimKiemDG.TabIndex = 35;
            this.btnTimKiemDG.Text = "Tìm kiếm";
            this.btnTimKiemDG.UseVisualStyleBackColor = true;
            this.btnTimKiemDG.Click += new System.EventHandler(this.btnTimKiemDG_Click);
            // 
            // btnXoaDG
            // 
            this.btnXoaDG.Location = new System.Drawing.Point(523, 200);
            this.btnXoaDG.Name = "btnXoaDG";
            this.btnXoaDG.Size = new System.Drawing.Size(75, 33);
            this.btnXoaDG.TabIndex = 34;
            this.btnXoaDG.Text = "Xóa";
            this.btnXoaDG.UseVisualStyleBackColor = true;
            this.btnXoaDG.Click += new System.EventHandler(this.btnXoaDG_Click);
            // 
            // btnSuaDG
            // 
            this.btnSuaDG.Location = new System.Drawing.Point(361, 200);
            this.btnSuaDG.Name = "btnSuaDG";
            this.btnSuaDG.Size = new System.Drawing.Size(75, 33);
            this.btnSuaDG.TabIndex = 33;
            this.btnSuaDG.Text = "Sửa";
            this.btnSuaDG.UseVisualStyleBackColor = true;
            this.btnSuaDG.Click += new System.EventHandler(this.btnSuaDG_Click);
            // 
            // btnThemDG
            // 
            this.btnThemDG.Location = new System.Drawing.Point(163, 200);
            this.btnThemDG.Name = "btnThemDG";
            this.btnThemDG.Size = new System.Drawing.Size(75, 33);
            this.btnThemDG.TabIndex = 32;
            this.btnThemDG.Text = "Thêm";
            this.btnThemDG.UseVisualStyleBackColor = true;
            this.btnThemDG.Click += new System.EventHandler(this.btnThemDG_Click);
            // 
            // txtDiaChiDG
            // 
            this.txtDiaChiDG.Location = new System.Drawing.Point(825, 83);
            this.txtDiaChiDG.Name = "txtDiaChiDG";
            this.txtDiaChiDG.Size = new System.Drawing.Size(192, 22);
            this.txtDiaChiDG.TabIndex = 31;
            // 
            // txtSDTDG
            // 
            this.txtSDTDG.Location = new System.Drawing.Point(825, 138);
            this.txtSDTDG.Name = "txtSDTDG";
            this.txtSDTDG.Size = new System.Drawing.Size(192, 22);
            this.txtSDTDG.TabIndex = 30;
            this.txtSDTDG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDTDG_KeyPress);
            // 
            // txtEmailDG
            // 
            this.txtEmailDG.Location = new System.Drawing.Point(523, 138);
            this.txtEmailDG.Name = "txtEmailDG";
            this.txtEmailDG.Size = new System.Drawing.Size(192, 22);
            this.txtEmailDG.TabIndex = 29;
            // 
            // dtNgaySinhDG
            // 
            this.dtNgaySinhDG.CustomFormat = "yyyy-MM-dd";
            this.dtNgaySinhDG.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgaySinhDG.Location = new System.Drawing.Point(523, 81);
            this.dtNgaySinhDG.Name = "dtNgaySinhDG";
            this.dtNgaySinhDG.Size = new System.Drawing.Size(192, 22);
            this.dtNgaySinhDG.TabIndex = 28;
            // 
            // txtMaDG
            // 
            this.txtMaDG.Location = new System.Drawing.Point(244, 83);
            this.txtMaDG.Name = "txtMaDG";
            this.txtMaDG.Size = new System.Drawing.Size(192, 22);
            this.txtMaDG.TabIndex = 27;
            // 
            // txtHoTenDG
            // 
            this.txtHoTenDG.Location = new System.Drawing.Point(244, 138);
            this.txtHoTenDG.Name = "txtHoTenDG";
            this.txtHoTenDG.Size = new System.Drawing.Size(192, 22);
            this.txtHoTenDG.TabIndex = 26;
            this.txtHoTenDG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHoTenDG_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(764, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 17);
            this.label11.TabIndex = 25;
            this.label11.Text = "Địa chỉ:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(724, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 17);
            this.label12.TabIndex = 24;
            this.label12.Text = "Số điện thoại:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(471, 141);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 17);
            this.label13.TabIndex = 23;
            this.label13.Text = "Email:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(442, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 17);
            this.label14.TabIndex = 22;
            this.label14.Text = "Ngày sinh:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(134, 141);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 17);
            this.label15.TabIndex = 21;
            this.label15.Text = "Họ tên độc giả:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(157, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 17);
            this.label16.TabIndex = 20;
            this.label16.Text = "Mã độc giả:";
            // 
            // tpQLS
            // 
            this.tpQLS.Controls.Add(this.txtNamXB);
            this.tpQLS.Controls.Add(this.label17);
            this.tpQLS.Controls.Add(this.label18);
            this.tpQLS.Controls.Add(this.txtNXB);
            this.tpQLS.Controls.Add(this.txtTacGia);
            this.tpQLS.Controls.Add(this.label19);
            this.tpQLS.Controls.Add(this.label20);
            this.tpQLS.Controls.Add(this.txtTKS);
            this.tpQLS.Controls.Add(this.dgvQLSach);
            this.tpQLS.Controls.Add(this.btnTKS);
            this.tpQLS.Controls.Add(this.btnXoaS);
            this.tpQLS.Controls.Add(this.btnSuaS);
            this.tpQLS.Controls.Add(this.btnThemS);
            this.tpQLS.Controls.Add(this.txtGiaS);
            this.tpQLS.Controls.Add(this.txtMaTLS);
            this.tpQLS.Controls.Add(this.txtTinhTrangS);
            this.tpQLS.Controls.Add(this.txtTenSach);
            this.tpQLS.Controls.Add(this.txtMaS);
            this.tpQLS.Controls.Add(this.label21);
            this.tpQLS.Controls.Add(this.label22);
            this.tpQLS.Controls.Add(this.label23);
            this.tpQLS.Controls.Add(this.label24);
            this.tpQLS.Controls.Add(this.label25);
            this.tpQLS.Location = new System.Drawing.Point(4, 25);
            this.tpQLS.Name = "tpQLS";
            this.tpQLS.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLS.Size = new System.Drawing.Size(1149, 463);
            this.tpQLS.TabIndex = 2;
            this.tpQLS.Text = "Quản lý sách";
            this.tpQLS.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(834, 158);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 17);
            this.label17.TabIndex = 46;
            this.label17.Text = "Năm XB:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.Location = new System.Drawing.Point(480, 39);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(161, 24);
            this.label18.TabIndex = 44;
            this.label18.Text = "QUẢN LÝ SÁCH";
            // 
            // txtNXB
            // 
            this.txtNXB.Location = new System.Drawing.Point(903, 103);
            this.txtNXB.Name = "txtNXB";
            this.txtNXB.Size = new System.Drawing.Size(148, 22);
            this.txtNXB.TabIndex = 43;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(666, 155);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(148, 22);
            this.txtTacGia.TabIndex = 42;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(857, 106);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 17);
            this.label19.TabIndex = 41;
            this.label19.Text = "NXB:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(601, 158);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 17);
            this.label20.TabIndex = 40;
            this.label20.Text = "Tác giả:";
            // 
            // txtTKS
            // 
            this.txtTKS.Location = new System.Drawing.Point(801, 219);
            this.txtTKS.Name = "txtTKS";
            this.txtTKS.Size = new System.Drawing.Size(148, 22);
            this.txtTKS.TabIndex = 39;
            // 
            // dgvQLSach
            // 
            this.dgvQLSach.AllowUserToAddRows = false;
            this.dgvQLSach.AllowUserToDeleteRows = false;
            this.dgvQLSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQLSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQLSach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSach,
            this.MaTLS,
            this.TinhTrang,
            this.NXB,
            this.TenSach,
            this.Gia,
            this.TacGia,
            this.NamXB});
            this.dgvQLSach.Location = new System.Drawing.Point(74, 274);
            this.dgvQLSach.Name = "dgvQLSach";
            this.dgvQLSach.ReadOnly = true;
            this.dgvQLSach.RowTemplate.Height = 24;
            this.dgvQLSach.Size = new System.Drawing.Size(1001, 150);
            this.dgvQLSach.TabIndex = 38;
            this.dgvQLSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQLSach_CellClick);
            // 
            // btnTKS
            // 
            this.btnTKS.Location = new System.Drawing.Point(709, 215);
            this.btnTKS.Name = "btnTKS";
            this.btnTKS.Size = new System.Drawing.Size(86, 30);
            this.btnTKS.TabIndex = 37;
            this.btnTKS.Text = "Tìm kiếm";
            this.btnTKS.UseVisualStyleBackColor = true;
            this.btnTKS.Click += new System.EventHandler(this.btnTKS_Click);
            // 
            // btnXoaS
            // 
            this.btnXoaS.Location = new System.Drawing.Point(543, 215);
            this.btnXoaS.Name = "btnXoaS";
            this.btnXoaS.Size = new System.Drawing.Size(75, 30);
            this.btnXoaS.TabIndex = 36;
            this.btnXoaS.Text = "Xóa";
            this.btnXoaS.UseVisualStyleBackColor = true;
            this.btnXoaS.Click += new System.EventHandler(this.btnXoaS_Click);
            // 
            // btnSuaS
            // 
            this.btnSuaS.Location = new System.Drawing.Point(394, 215);
            this.btnSuaS.Name = "btnSuaS";
            this.btnSuaS.Size = new System.Drawing.Size(75, 30);
            this.btnSuaS.TabIndex = 35;
            this.btnSuaS.Text = "Sửa";
            this.btnSuaS.UseVisualStyleBackColor = true;
            this.btnSuaS.Click += new System.EventHandler(this.btnSuaS_Click);
            // 
            // btnThemS
            // 
            this.btnThemS.Location = new System.Drawing.Point(239, 215);
            this.btnThemS.Name = "btnThemS";
            this.btnThemS.Size = new System.Drawing.Size(75, 30);
            this.btnThemS.TabIndex = 34;
            this.btnThemS.Text = "Thêm";
            this.btnThemS.UseVisualStyleBackColor = true;
            this.btnThemS.Click += new System.EventHandler(this.btnThemS_Click);
            // 
            // txtGiaS
            // 
            this.txtGiaS.Location = new System.Drawing.Point(412, 155);
            this.txtGiaS.Name = "txtGiaS";
            this.txtGiaS.Size = new System.Drawing.Size(148, 22);
            this.txtGiaS.TabIndex = 33;
            this.txtGiaS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGiaS_KeyPress);
            // 
            // txtMaTLS
            // 
            this.txtMaTLS.Location = new System.Drawing.Point(412, 103);
            this.txtMaTLS.Name = "txtMaTLS";
            this.txtMaTLS.Size = new System.Drawing.Size(148, 22);
            this.txtMaTLS.TabIndex = 32;
            // 
            // txtTinhTrangS
            // 
            this.txtTinhTrangS.Location = new System.Drawing.Point(666, 103);
            this.txtTinhTrangS.Name = "txtTinhTrangS";
            this.txtTinhTrangS.Size = new System.Drawing.Size(148, 22);
            this.txtTinhTrangS.TabIndex = 31;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(166, 155);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(148, 22);
            this.txtTenSach.TabIndex = 30;
            // 
            // txtMaS
            // 
            this.txtMaS.Location = new System.Drawing.Point(166, 103);
            this.txtMaS.Name = "txtMaS";
            this.txtMaS.Size = new System.Drawing.Size(148, 22);
            this.txtMaS.TabIndex = 29;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(583, 109);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 17);
            this.label21.TabIndex = 28;
            this.label21.Text = "Tình trạng:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(372, 158);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 17);
            this.label22.TabIndex = 27;
            this.label22.Text = "Giá:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(325, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 17);
            this.label23.TabIndex = 26;
            this.label23.Text = "Mã thể loại:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(89, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 17);
            this.label24.TabIndex = 25;
            this.label24.Text = "Tên sách:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(89, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 17);
            this.label25.TabIndex = 24;
            this.label25.Text = "Mã sách:";
            // 
            // tpQLTL
            // 
            this.tpQLTL.Controls.Add(this.label26);
            this.tpQLTL.Controls.Add(this.txtTKTL);
            this.tpQLTL.Controls.Add(this.dgvTheLoai);
            this.tpQLTL.Controls.Add(this.btnTKTL);
            this.tpQLTL.Controls.Add(this.btnXoaTL);
            this.tpQLTL.Controls.Add(this.btnSuaTL);
            this.tpQLTL.Controls.Add(this.btnThemTL);
            this.tpQLTL.Controls.Add(this.txtTenTL);
            this.tpQLTL.Controls.Add(this.txtMaTL);
            this.tpQLTL.Controls.Add(this.label27);
            this.tpQLTL.Controls.Add(this.label28);
            this.tpQLTL.Location = new System.Drawing.Point(4, 25);
            this.tpQLTL.Name = "tpQLTL";
            this.tpQLTL.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLTL.Size = new System.Drawing.Size(1149, 463);
            this.tpQLTL.TabIndex = 3;
            this.tpQLTL.Text = "Quản lý thể loại";
            this.tpQLTL.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label26.Location = new System.Drawing.Point(478, 37);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(199, 24);
            this.label26.TabIndex = 44;
            this.label26.Text = "QUẢN LÝ THỂ LOẠI";
            // 
            // txtTKTL
            // 
            this.txtTKTL.Location = new System.Drawing.Point(557, 243);
            this.txtTKTL.Name = "txtTKTL";
            this.txtTKTL.Size = new System.Drawing.Size(148, 22);
            this.txtTKTL.TabIndex = 43;
            // 
            // dgvTheLoai
            // 
            this.dgvTheLoai.AllowUserToAddRows = false;
            this.dgvTheLoai.AllowUserToDeleteRows = false;
            this.dgvTheLoai.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTheLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheLoai.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaTL,
            this.TenTL});
            this.dgvTheLoai.Location = new System.Drawing.Point(380, 275);
            this.dgvTheLoai.Name = "dgvTheLoai";
            this.dgvTheLoai.ReadOnly = true;
            this.dgvTheLoai.RowTemplate.Height = 24;
            this.dgvTheLoai.Size = new System.Drawing.Size(389, 150);
            this.dgvTheLoai.TabIndex = 42;
            this.dgvTheLoai.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTheLoai_CellClick);
            // 
            // MaTL
            // 
            this.MaTL.DataPropertyName = "MaTL";
            this.MaTL.HeaderText = "Mã thể loại";
            this.MaTL.Name = "MaTL";
            this.MaTL.ReadOnly = true;
            // 
            // TenTL
            // 
            this.TenTL.DataPropertyName = "TenTL";
            this.TenTL.HeaderText = "Tên thể loại";
            this.TenTL.Name = "TenTL";
            this.TenTL.ReadOnly = true;
            // 
            // btnTKTL
            // 
            this.btnTKTL.Location = new System.Drawing.Point(467, 239);
            this.btnTKTL.Name = "btnTKTL";
            this.btnTKTL.Size = new System.Drawing.Size(84, 30);
            this.btnTKTL.TabIndex = 41;
            this.btnTKTL.Text = "Tìm kiếm";
            this.btnTKTL.UseVisualStyleBackColor = true;
            this.btnTKTL.Click += new System.EventHandler(this.btnTKTL_Click);
            // 
            // btnXoaTL
            // 
            this.btnXoaTL.Location = new System.Drawing.Point(643, 188);
            this.btnXoaTL.Name = "btnXoaTL";
            this.btnXoaTL.Size = new System.Drawing.Size(75, 30);
            this.btnXoaTL.TabIndex = 40;
            this.btnXoaTL.Text = "Xóa";
            this.btnXoaTL.UseVisualStyleBackColor = true;
            this.btnXoaTL.Click += new System.EventHandler(this.btnXoaTL_Click);
            // 
            // btnSuaTL
            // 
            this.btnSuaTL.Location = new System.Drawing.Point(540, 188);
            this.btnSuaTL.Name = "btnSuaTL";
            this.btnSuaTL.Size = new System.Drawing.Size(75, 30);
            this.btnSuaTL.TabIndex = 39;
            this.btnSuaTL.Text = "Sửa";
            this.btnSuaTL.UseVisualStyleBackColor = true;
            this.btnSuaTL.Click += new System.EventHandler(this.btnSuaTL_Click);
            // 
            // btnThemTL
            // 
            this.btnThemTL.Location = new System.Drawing.Point(438, 188);
            this.btnThemTL.Name = "btnThemTL";
            this.btnThemTL.Size = new System.Drawing.Size(75, 30);
            this.btnThemTL.TabIndex = 38;
            this.btnThemTL.Text = "Thêm";
            this.btnThemTL.UseVisualStyleBackColor = true;
            this.btnThemTL.Click += new System.EventHandler(this.btnThemTL_Click);
            // 
            // txtTenTL
            // 
            this.txtTenTL.Location = new System.Drawing.Point(551, 149);
            this.txtTenTL.Name = "txtTenTL";
            this.txtTenTL.Size = new System.Drawing.Size(148, 22);
            this.txtTenTL.TabIndex = 37;
            // 
            // txtMaTL
            // 
            this.txtMaTL.Location = new System.Drawing.Point(551, 96);
            this.txtMaTL.Name = "txtMaTL";
            this.txtMaTL.Size = new System.Drawing.Size(148, 22);
            this.txtMaTL.TabIndex = 36;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(458, 152);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(87, 17);
            this.label27.TabIndex = 35;
            this.label27.Text = "Tên thể loại:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(464, 99);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(81, 17);
            this.label28.TabIndex = 34;
            this.label28.Text = "Mã thể loại:";
            // 
            // tpQLPMT
            // 
            this.tpQLPMT.Controls.Add(this.txtMaDGPMT);
            this.tpQLPMT.Controls.Add(this.label29);
            this.tpQLPMT.Controls.Add(this.label30);
            this.tpQLPMT.Controls.Add(this.txtTKPMT);
            this.tpQLPMT.Controls.Add(this.btnTKPMT);
            this.tpQLPMT.Controls.Add(this.btnXoaPMT);
            this.tpQLPMT.Controls.Add(this.btnSuaPMT);
            this.tpQLPMT.Controls.Add(this.btnThemPMT);
            this.tpQLPMT.Controls.Add(this.dgvMuonTra);
            this.tpQLPMT.Controls.Add(this.dtNgayMuon);
            this.tpQLPMT.Controls.Add(this.txtMaPM);
            this.tpQLPMT.Controls.Add(this.label31);
            this.tpQLPMT.Controls.Add(this.label32);
            this.tpQLPMT.Location = new System.Drawing.Point(4, 25);
            this.tpQLPMT.Name = "tpQLPMT";
            this.tpQLPMT.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLPMT.Size = new System.Drawing.Size(1149, 463);
            this.tpQLPMT.TabIndex = 4;
            this.tpQLPMT.Text = "Quản lý phiếu mượn trả";
            this.tpQLPMT.UseVisualStyleBackColor = true;
            // 
            // txtMaDGPMT
            // 
            this.txtMaDGPMT.Location = new System.Drawing.Point(658, 86);
            this.txtMaDGPMT.Name = "txtMaDGPMT";
            this.txtMaDGPMT.Size = new System.Drawing.Size(175, 22);
            this.txtMaDGPMT.TabIndex = 34;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(571, 89);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(81, 17);
            this.label29.TabIndex = 33;
            this.label29.Text = "Mã độc giả:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label30.Location = new System.Drawing.Point(453, 30);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(214, 24);
            this.label30.TabIndex = 32;
            this.label30.Text = "QUẢN LÝ MƯỢN TRẢ";
            // 
            // txtTKPMT
            // 
            this.txtTKPMT.Location = new System.Drawing.Point(547, 239);
            this.txtTKPMT.Name = "txtTKPMT";
            this.txtTKPMT.Size = new System.Drawing.Size(156, 22);
            this.txtTKPMT.TabIndex = 31;
            // 
            // btnTKPMT
            // 
            this.btnTKPMT.Location = new System.Drawing.Point(457, 236);
            this.btnTKPMT.Name = "btnTKPMT";
            this.btnTKPMT.Size = new System.Drawing.Size(84, 28);
            this.btnTKPMT.TabIndex = 30;
            this.btnTKPMT.Text = "Tìm kiếm";
            this.btnTKPMT.UseVisualStyleBackColor = true;
            this.btnTKPMT.Click += new System.EventHandler(this.btnTKPMT_Click);
            // 
            // btnXoaPMT
            // 
            this.btnXoaPMT.Location = new System.Drawing.Point(651, 184);
            this.btnXoaPMT.Name = "btnXoaPMT";
            this.btnXoaPMT.Size = new System.Drawing.Size(75, 28);
            this.btnXoaPMT.TabIndex = 29;
            this.btnXoaPMT.Text = "Xóa";
            this.btnXoaPMT.UseVisualStyleBackColor = true;
            this.btnXoaPMT.Click += new System.EventHandler(this.btnXoaPMT_Click);
            // 
            // btnSuaPMT
            // 
            this.btnSuaPMT.Location = new System.Drawing.Point(556, 184);
            this.btnSuaPMT.Name = "btnSuaPMT";
            this.btnSuaPMT.Size = new System.Drawing.Size(75, 28);
            this.btnSuaPMT.TabIndex = 28;
            this.btnSuaPMT.Text = "Sửa";
            this.btnSuaPMT.UseVisualStyleBackColor = true;
            this.btnSuaPMT.Click += new System.EventHandler(this.btnSuaPMT_Click);
            // 
            // btnThemPMT
            // 
            this.btnThemPMT.Location = new System.Drawing.Point(457, 184);
            this.btnThemPMT.Name = "btnThemPMT";
            this.btnThemPMT.Size = new System.Drawing.Size(75, 28);
            this.btnThemPMT.TabIndex = 27;
            this.btnThemPMT.Text = "Thêm";
            this.btnThemPMT.UseVisualStyleBackColor = true;
            this.btnThemPMT.Click += new System.EventHandler(this.btnThemPMT_Click);
            // 
            // dgvMuonTra
            // 
            this.dgvMuonTra.AllowUserToAddRows = false;
            this.dgvMuonTra.AllowUserToDeleteRows = false;
            this.dgvMuonTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMuonTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMuonTra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPM,
            this.MaDGPMT,
            this.NgayMuon});
            this.dgvMuonTra.Location = new System.Drawing.Point(275, 283);
            this.dgvMuonTra.Name = "dgvMuonTra";
            this.dgvMuonTra.ReadOnly = true;
            this.dgvMuonTra.RowTemplate.Height = 24;
            this.dgvMuonTra.Size = new System.Drawing.Size(609, 150);
            this.dgvMuonTra.TabIndex = 26;
            this.dgvMuonTra.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMuonTra_CellClick);
            // 
            // MaPM
            // 
            this.MaPM.DataPropertyName = "MaPM";
            this.MaPM.HeaderText = "Mã phiếu mượn";
            this.MaPM.Name = "MaPM";
            this.MaPM.ReadOnly = true;
            // 
            // MaDGPMT
            // 
            this.MaDGPMT.DataPropertyName = "MaDGPMT";
            this.MaDGPMT.HeaderText = "Mã độc giả";
            this.MaDGPMT.Name = "MaDGPMT";
            this.MaDGPMT.ReadOnly = true;
            // 
            // NgayMuon
            // 
            this.NgayMuon.DataPropertyName = "NgayMuon";
            this.NgayMuon.HeaderText = "Ngày mượn";
            this.NgayMuon.Name = "NgayMuon";
            this.NgayMuon.ReadOnly = true;
            // 
            // dtNgayMuon
            // 
            this.dtNgayMuon.CustomFormat = "yyyy-MM-dd";
            this.dtNgayMuon.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayMuon.Location = new System.Drawing.Point(512, 134);
            this.dtNgayMuon.Name = "dtNgayMuon";
            this.dtNgayMuon.Size = new System.Drawing.Size(175, 22);
            this.dtNgayMuon.TabIndex = 25;
            // 
            // txtMaPM
            // 
            this.txtMaPM.Location = new System.Drawing.Point(379, 86);
            this.txtMaPM.Name = "txtMaPM";
            this.txtMaPM.Size = new System.Drawing.Size(175, 22);
            this.txtMaPM.TabIndex = 24;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(422, 139);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(84, 17);
            this.label31.TabIndex = 23;
            this.label31.Text = "Ngày mượn:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(264, 89);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(109, 17);
            this.label32.TabIndex = 22;
            this.label32.Text = "Mã phiếu mượn:";
            // 
            // tpQLCTPMPT
            // 
            this.tpQLCTPMPT.Controls.Add(this.txtPhieuMuonCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.label33);
            this.tpQLCTPMPT.Controls.Add(this.txtMaSachCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.label34);
            this.tpQLCTPMPT.Controls.Add(this.label35);
            this.tpQLCTPMPT.Controls.Add(this.dgvQLCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.txtTKCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.btnTKCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.btnXoaCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.btnSuaCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.btnThemCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.dtNgayTra);
            this.tpQLCTPMPT.Controls.Add(this.txtTinhTrangCTPMT);
            this.tpQLCTPMPT.Controls.Add(this.txtGhiChu);
            this.tpQLCTPMPT.Controls.Add(this.txtTienPhat);
            this.tpQLCTPMPT.Controls.Add(this.txtMaCTPM);
            this.tpQLCTPMPT.Controls.Add(this.label36);
            this.tpQLCTPMPT.Controls.Add(this.label37);
            this.tpQLCTPMPT.Controls.Add(this.label38);
            this.tpQLCTPMPT.Controls.Add(this.label39);
            this.tpQLCTPMPT.Controls.Add(this.label40);
            this.tpQLCTPMPT.Location = new System.Drawing.Point(4, 25);
            this.tpQLCTPMPT.Name = "tpQLCTPMPT";
            this.tpQLCTPMPT.Padding = new System.Windows.Forms.Padding(3);
            this.tpQLCTPMPT.Size = new System.Drawing.Size(1149, 463);
            this.tpQLCTPMPT.TabIndex = 5;
            this.tpQLCTPMPT.Text = "Quản lý chi tiết phiếu mượn trả";
            this.tpQLCTPMPT.UseVisualStyleBackColor = true;
            // 
            // txtPhieuMuonCTPMT
            // 
            this.txtPhieuMuonCTPMT.Location = new System.Drawing.Point(678, 93);
            this.txtPhieuMuonCTPMT.Name = "txtPhieuMuonCTPMT";
            this.txtPhieuMuonCTPMT.Size = new System.Drawing.Size(137, 22);
            this.txtPhieuMuonCTPMT.TabIndex = 43;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(617, 96);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(55, 17);
            this.label33.TabIndex = 42;
            this.label33.Text = "Mã PM:";
            // 
            // txtMaSachCTPMT
            // 
            this.txtMaSachCTPMT.Location = new System.Drawing.Point(415, 93);
            this.txtMaSachCTPMT.Name = "txtMaSachCTPMT";
            this.txtMaSachCTPMT.Size = new System.Drawing.Size(156, 22);
            this.txtMaSachCTPMT.TabIndex = 41;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(342, 96);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(67, 17);
            this.label34.TabIndex = 40;
            this.label34.Text = "Mã Sách:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label35.Location = new System.Drawing.Point(384, 37);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(372, 24);
            this.label35.TabIndex = 39;
            this.label35.Text = "QUẢN LÝ CHI TIẾT PHIẾU MƯỢN TRẢ";
            // 
            // dgvQLCTPMT
            // 
            this.dgvQLCTPMT.AllowUserToAddRows = false;
            this.dgvQLCTPMT.AllowUserToDeleteRows = false;
            this.dgvQLCTPMT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQLCTPMT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQLCTPMT.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCTPMT,
            this.MaSachCTPMT,
            this.MaPMCTPMT,
            this.dataGridViewTextBoxColumn9,
            this.NgayTra,
            this.GhiChu,
            this.TienPhat});
            this.dgvQLCTPMT.Location = new System.Drawing.Point(99, 276);
            this.dgvQLCTPMT.Name = "dgvQLCTPMT";
            this.dgvQLCTPMT.ReadOnly = true;
            this.dgvQLCTPMT.RowTemplate.Height = 24;
            this.dgvQLCTPMT.Size = new System.Drawing.Size(961, 150);
            this.dgvQLCTPMT.TabIndex = 38;
            this.dgvQLCTPMT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQLCTPMT_CellClick);
            // 
            // MaCTPMT
            // 
            this.MaCTPMT.DataPropertyName = "MaCTPMT";
            this.MaCTPMT.HeaderText = "Mã chi tiết PM";
            this.MaCTPMT.Name = "MaCTPMT";
            this.MaCTPMT.ReadOnly = true;
            // 
            // MaSachCTPMT
            // 
            this.MaSachCTPMT.DataPropertyName = "MaSachCTPMT";
            this.MaSachCTPMT.HeaderText = "Mã Sách";
            this.MaSachCTPMT.Name = "MaSachCTPMT";
            this.MaSachCTPMT.ReadOnly = true;
            // 
            // MaPMCTPMT
            // 
            this.MaPMCTPMT.DataPropertyName = "MaPMCTPMT";
            this.MaPMCTPMT.HeaderText = "Mã phiếu mượn";
            this.MaPMCTPMT.Name = "MaPMCTPMT";
            this.MaPMCTPMT.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "TinhTrang";
            this.dataGridViewTextBoxColumn9.HeaderText = "Tình trạng";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // NgayTra
            // 
            this.NgayTra.DataPropertyName = "NgayTra";
            this.NgayTra.HeaderText = "Ngày trả";
            this.NgayTra.Name = "NgayTra";
            this.NgayTra.ReadOnly = true;
            // 
            // GhiChu
            // 
            this.GhiChu.DataPropertyName = "GhiChu";
            this.GhiChu.HeaderText = "Ghi chú";
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.ReadOnly = true;
            // 
            // TienPhat
            // 
            this.TienPhat.DataPropertyName = "TienPhat";
            this.TienPhat.HeaderText = "Tiền phạt";
            this.TienPhat.Name = "TienPhat";
            this.TienPhat.ReadOnly = true;
            // 
            // txtTKCTPMT
            // 
            this.txtTKCTPMT.Location = new System.Drawing.Point(885, 213);
            this.txtTKCTPMT.Name = "txtTKCTPMT";
            this.txtTKCTPMT.Size = new System.Drawing.Size(175, 22);
            this.txtTKCTPMT.TabIndex = 37;
            // 
            // btnTKCTPMT
            // 
            this.btnTKCTPMT.Location = new System.Drawing.Point(800, 209);
            this.btnTKCTPMT.Name = "btnTKCTPMT";
            this.btnTKCTPMT.Size = new System.Drawing.Size(79, 31);
            this.btnTKCTPMT.TabIndex = 36;
            this.btnTKCTPMT.Text = "Tìm kiếm";
            this.btnTKCTPMT.UseVisualStyleBackColor = true;
            this.btnTKCTPMT.Click += new System.EventHandler(this.btnTKCTPMT_Click);
            // 
            // btnXoaCTPMT
            // 
            this.btnXoaCTPMT.Location = new System.Drawing.Point(593, 209);
            this.btnXoaCTPMT.Name = "btnXoaCTPMT";
            this.btnXoaCTPMT.Size = new System.Drawing.Size(79, 31);
            this.btnXoaCTPMT.TabIndex = 35;
            this.btnXoaCTPMT.Text = "Xóa";
            this.btnXoaCTPMT.UseVisualStyleBackColor = true;
            this.btnXoaCTPMT.Click += new System.EventHandler(this.btnXoaCTPMT_Click);
            // 
            // btnSuaCTPMT
            // 
            this.btnSuaCTPMT.Location = new System.Drawing.Point(354, 213);
            this.btnSuaCTPMT.Name = "btnSuaCTPMT";
            this.btnSuaCTPMT.Size = new System.Drawing.Size(79, 31);
            this.btnSuaCTPMT.TabIndex = 34;
            this.btnSuaCTPMT.Text = "Sửa";
            this.btnSuaCTPMT.UseVisualStyleBackColor = true;
            this.btnSuaCTPMT.Click += new System.EventHandler(this.btnSuaCTPMT_Click);
            // 
            // btnThemCTPMT
            // 
            this.btnThemCTPMT.Location = new System.Drawing.Point(98, 213);
            this.btnThemCTPMT.Name = "btnThemCTPMT";
            this.btnThemCTPMT.Size = new System.Drawing.Size(79, 31);
            this.btnThemCTPMT.TabIndex = 33;
            this.btnThemCTPMT.Text = "Thêm";
            this.btnThemCTPMT.UseVisualStyleBackColor = true;
            this.btnThemCTPMT.Click += new System.EventHandler(this.btnThemCTPMT_Click);
            // 
            // dtNgayTra
            // 
            this.dtNgayTra.CustomFormat = "yyyy-MM-dd";
            this.dtNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayTra.Location = new System.Drawing.Point(167, 148);
            this.dtNgayTra.Name = "dtNgayTra";
            this.dtNgayTra.Size = new System.Drawing.Size(156, 22);
            this.dtNgayTra.TabIndex = 32;
            // 
            // txtTinhTrangCTPMT
            // 
            this.txtTinhTrangCTPMT.Location = new System.Drawing.Point(926, 93);
            this.txtTinhTrangCTPMT.Name = "txtTinhTrangCTPMT";
            this.txtTinhTrangCTPMT.Size = new System.Drawing.Size(134, 22);
            this.txtTinhTrangCTPMT.TabIndex = 31;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(421, 150);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(150, 22);
            this.txtGhiChu.TabIndex = 30;
            // 
            // txtTienPhat
            // 
            this.txtTienPhat.Location = new System.Drawing.Point(678, 150);
            this.txtTienPhat.Name = "txtTienPhat";
            this.txtTienPhat.Size = new System.Drawing.Size(137, 22);
            this.txtTienPhat.TabIndex = 29;
            this.txtTienPhat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTienPhat_KeyPress);
            // 
            // txtMaCTPM
            // 
            this.txtMaCTPM.Location = new System.Drawing.Point(167, 93);
            this.txtMaCTPM.Name = "txtMaCTPM";
            this.txtMaCTPM.Size = new System.Drawing.Size(156, 22);
            this.txtMaCTPM.TabIndex = 28;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(843, 96);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 17);
            this.label36.TabIndex = 27;
            this.label36.Text = "Tình trạng:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(354, 153);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 17);
            this.label37.TabIndex = 26;
            this.label37.Text = "Ghi chú:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(600, 153);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(72, 17);
            this.label38.TabIndex = 25;
            this.label38.Text = "Tiền phạt:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(95, 153);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 17);
            this.label39.TabIndex = 24;
            this.label39.Text = "Ngày trả:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(88, 96);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(73, 17);
            this.label40.TabIndex = 23;
            this.label40.Text = "Mã CTPM:";
            // 
            // MaSach
            // 
            this.MaSach.DataPropertyName = "MaSach";
            this.MaSach.HeaderText = "Mã sách";
            this.MaSach.Name = "MaSach";
            this.MaSach.ReadOnly = true;
            // 
            // MaTLS
            // 
            this.MaTLS.DataPropertyName = "MaTLS";
            this.MaTLS.HeaderText = "Mã thể loại";
            this.MaTLS.Name = "MaTLS";
            this.MaTLS.ReadOnly = true;
            // 
            // TinhTrang
            // 
            this.TinhTrang.DataPropertyName = "TinhTrang";
            this.TinhTrang.HeaderText = "Tình trạng";
            this.TinhTrang.Name = "TinhTrang";
            this.TinhTrang.ReadOnly = true;
            // 
            // NXB
            // 
            this.NXB.DataPropertyName = "NXB";
            this.NXB.HeaderText = "NXB";
            this.NXB.Name = "NXB";
            this.NXB.ReadOnly = true;
            // 
            // TenSach
            // 
            this.TenSach.DataPropertyName = "TenSach";
            this.TenSach.HeaderText = "Tên sách";
            this.TenSach.Name = "TenSach";
            this.TenSach.ReadOnly = true;
            // 
            // Gia
            // 
            this.Gia.DataPropertyName = "Gia";
            this.Gia.HeaderText = "Giá";
            this.Gia.Name = "Gia";
            this.Gia.ReadOnly = true;
            // 
            // TacGia
            // 
            this.TacGia.DataPropertyName = "TacGia";
            this.TacGia.HeaderText = "Tác giả";
            this.TacGia.Name = "TacGia";
            this.TacGia.ReadOnly = true;
            // 
            // NamXB
            // 
            this.NamXB.DataPropertyName = "NamXB";
            this.NamXB.HeaderText = "Năm xuất bản";
            this.NamXB.Name = "NamXB";
            this.NamXB.ReadOnly = true;
            // 
            // txtNamXB
            // 
            this.txtNamXB.Location = new System.Drawing.Point(903, 155);
            this.txtNamXB.Name = "txtNamXB";
            this.txtNamXB.Size = new System.Drawing.Size(148, 22);
            this.txtNamXB.TabIndex = 47;
            // 
            // frmQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1181, 516);
            this.Controls.Add(this.tcQuanLy);
            this.Name = "frmQuanLy";
            this.Text = "Quản Lý";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuanLy_FormClosing);
            this.Load += new System.EventHandler(this.frmQuanLy_Load);
            this.tcQuanLy.ResumeLayout(false);
            this.tpQLTK.ResumeLayout(false);
            this.tpQLTK.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaiKhoan)).EndInit();
            this.tpQLDG.ResumeLayout(false);
            this.tpQLDG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.tpQLS.ResumeLayout(false);
            this.tpQLS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLSach)).EndInit();
            this.tpQLTL.ResumeLayout(false);
            this.tpQLTL.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheLoai)).EndInit();
            this.tpQLPMT.ResumeLayout(false);
            this.tpQLPMT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMuonTra)).EndInit();
            this.tpQLCTPMPT.ResumeLayout(false);
            this.tpQLCTPMPT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLCTPMT)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcQuanLy;
        private System.Windows.Forms.TabPage tpQLTK;
        private System.Windows.Forms.ComboBox cbVaiTro;
        private System.Windows.Forms.DateTimePicker dtNgaySinh;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.DataGridView dgvTaiKhoan;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTenNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn VaiTro;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn SDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tpQLDG;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTimKiemDG;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDG;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTenDG;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button btnTimKiemDG;
        private System.Windows.Forms.Button btnXoaDG;
        private System.Windows.Forms.Button btnSuaDG;
        private System.Windows.Forms.Button btnThemDG;
        private System.Windows.Forms.TextBox txtDiaChiDG;
        private System.Windows.Forms.TextBox txtSDTDG;
        private System.Windows.Forms.TextBox txtEmailDG;
        private System.Windows.Forms.DateTimePicker dtNgaySinhDG;
        private System.Windows.Forms.TextBox txtMaDG;
        private System.Windows.Forms.TextBox txtHoTenDG;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tpQLS;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtNXB;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtTKS;
        private System.Windows.Forms.DataGridView dgvQLSach;
        private System.Windows.Forms.Button btnTKS;
        private System.Windows.Forms.Button btnXoaS;
        private System.Windows.Forms.Button btnSuaS;
        private System.Windows.Forms.Button btnThemS;
        private System.Windows.Forms.TextBox txtGiaS;
        private System.Windows.Forms.TextBox txtMaTLS;
        private System.Windows.Forms.TextBox txtTinhTrangS;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.TextBox txtMaS;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tpQLTL;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtTKTL;
        private System.Windows.Forms.DataGridView dgvTheLoai;
        private System.Windows.Forms.Button btnTKTL;
        private System.Windows.Forms.Button btnXoaTL;
        private System.Windows.Forms.Button btnSuaTL;
        private System.Windows.Forms.Button btnThemTL;
        private System.Windows.Forms.TextBox txtTenTL;
        private System.Windows.Forms.TextBox txtMaTL;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage tpQLPMT;
        private System.Windows.Forms.TextBox txtMaDGPMT;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtTKPMT;
        private System.Windows.Forms.Button btnTKPMT;
        private System.Windows.Forms.Button btnXoaPMT;
        private System.Windows.Forms.Button btnSuaPMT;
        private System.Windows.Forms.Button btnThemPMT;
        private System.Windows.Forms.DataGridView dgvMuonTra;
        private System.Windows.Forms.DateTimePicker dtNgayMuon;
        private System.Windows.Forms.TextBox txtMaPM;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage tpQLCTPMPT;
        private System.Windows.Forms.TextBox txtPhieuMuonCTPMT;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtMaSachCTPMT;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView dgvQLCTPMT;
        private System.Windows.Forms.TextBox txtTKCTPMT;
        private System.Windows.Forms.Button btnTKCTPMT;
        private System.Windows.Forms.Button btnXoaCTPMT;
        private System.Windows.Forms.Button btnSuaCTPMT;
        private System.Windows.Forms.Button btnThemCTPMT;
        private System.Windows.Forms.DateTimePicker dtNgayTra;
        private System.Windows.Forms.TextBox txtTinhTrangCTPMT;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.TextBox txtTienPhat;
        private System.Windows.Forms.TextBox txtMaCTPM;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPM;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDGPMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayMuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCTPMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSachCTPMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPMCTPMT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayTra;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
        private System.Windows.Forms.DataGridViewTextBoxColumn TienPhat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTL;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenTL;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTLS;
        private System.Windows.Forms.DataGridViewTextBoxColumn TinhTrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn NXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gia;
        private System.Windows.Forms.DataGridViewTextBoxColumn TacGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn NamXB;
        private System.Windows.Forms.TextBox txtNamXB;
    }
}