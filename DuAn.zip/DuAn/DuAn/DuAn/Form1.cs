﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DuAn
{
    public partial class frmFromMain : Form
    {
        public frmFromMain()
        {
            InitializeComponent();
        }
        public static string VaiTro;
        public class ThongTinDangNhap
        {
            public static string TenDangNhap;
        }
        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            //kết nối với CSDL
            Funtions.Connect();

            // Truy vấn cơ sở dữ liệu để kiểm tra đăng nhập
            string query = "SELECT VaiTro FROM NhanVien WHERE Username = @username AND Password = @password";
            using (SqlCommand command = new SqlCommand(query, Funtions.Con))
            {
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);

                // Lấy vai trò từ cơ sở dữ liệu
                VaiTro = (string)command.ExecuteScalar();

                if (!string.IsNullOrEmpty(VaiTro))
                {
                    ThongTinDangNhap.TenDangNhap = txtUsername.Text;
                    if (VaiTro == "Admin")
                    {
                        MessageBox.Show("Admin đăng nhập thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        frmQuanLy quanly = new frmQuanLy();
                        quanly.Show();
                        this.Hide();
                    }
                    else if (VaiTro == "Thủ Thư")
                    {
                        MessageBox.Show("Thủ thư đăng nhập thành công!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        frmQuanLy quanly = new frmQuanLy();
                        quanly.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Vai trò không hợp lệ!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng kiểm tra lại tài khoản!", "Thông báo!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
