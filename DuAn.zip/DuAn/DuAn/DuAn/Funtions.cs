﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DuAn
{
    class Funtions
    {
        public static SqlConnection Con;
        public static bool Connect()
        {
            string servername = @"VANTHUAN\SQLEXPRESS2012";
            string database = "DuAn";
            string ConnectionString = @"Data Source=" + servername + ";Initial Catalog = " + database + "; Integrated Security = SSPI";
            Con = new SqlConnection(ConnectionString);
            try
            {
                Con.Open();
                if (Con.State == ConnectionState.Open)
                    return true;
                else return false;
            }
            catch
            {
                return false;
            }
        }
        public static DataTable GetDataToTable(string SqlString)
        {
            SqlDataAdapter dap = new SqlDataAdapter(SqlString, Funtions.Con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            return dt;
        }
        public static bool CheckPK(string SqlString)
        {
            SqlDataAdapter dap = new SqlDataAdapter(SqlString, Con);
            DataTable dt = new DataTable();
            dap.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static void RunSQL(string SqlString)
        {
            SqlCommand cmd = new SqlCommand(SqlString, Con);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            cmd.Dispose();
            cmd = null;
        }
        public static object GetField(string sqlQuery)
        {
            using (SqlConnection connection = new SqlConnection())
            {               
                using (SqlCommand command = new SqlCommand(sqlQuery, Con))
                {
                    // Thực hiện truy vấn và trả về giá trị
                    return command.ExecuteScalar();
                }
            }
        }

        public static bool CheckRecord(string SqlStr)
        {
            Connect();
            SqlCommand cmd = new SqlCommand(SqlStr, Con);
            SqlDataReader reader = cmd.ExecuteReader();

            try
            {
                while (reader.Read())
                {
                    // Kiểm tra từng bản ghi
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (!reader.IsDBNull(i))
                        {
                            // Nếu có bản ghi không phải là NULL, trả về true
                            return true;
                        }
                    }
                }

                // Nếu không có bản ghi nào thỏa mãn điều kiện, trả về false
                return false;
            }
            finally
            {
                // Đảm bảo đóng kết nối sau khi sử dụng
                reader.Close();
                //Con.Close();
            }
        }
    }
    public static class CurrentUser
    {
        public static string Username { get; set; }
        public static string Role { get; set; }
    }
}
