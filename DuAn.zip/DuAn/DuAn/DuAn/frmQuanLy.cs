﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DuAn
{
    public partial class frmQuanLy : Form
    {
        public frmQuanLy()
        {
            InitializeComponent();
        }

        private void frmQuanLy_Load(object sender, EventArgs e)
        {
            cbVaiTro.Items.Clear();
            cbVaiTro.Items.Add("Admin");
            cbVaiTro.Items.Add("Thủ Thư");
            LoadDataGridViewQLTK();
            LoadDataGridViewDG();
            LoadDataGridViewPMT();
            LoadDataGridViewCTPMT();
            LoadDataGridViewS();
            LoadDataGridViewTL();
            Reset();
        }
        private bool CheckDate(DateTime dt)
        {
            if (dt.Year > DateTime.Today.Year)
                return false;
            if ((dt.Month > DateTime.Today.Month) && (dt.Year == DateTime.Today.Year))
                return false;
            if ((dt.Day > DateTime.Today.Day) && (dt.Month == DateTime.Today.Month) && (dt.Year == DateTime.Today.Year))
                return false;
            return true;
        }
        private void Reset()
        {
            //Form Quản lý tài khoản
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtHoTen.Text = "";
            //dtNgaySinh.Value = DateTime.Now;
            txtDiaChi.Text = "";
            txtEmail.Text = "";
            txtSDT.Text = "";

            cbVaiTro.SelectedIndex = -1;

            btnThem.Enabled = true;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;

            txtUsername.Enabled = true;

            //Form Quản lý độc giả
            txtMaDG.Text = "";
            txtHoTenDG.Text = "";
            txtSDTDG.Text = "";
            txtDiaChiDG.Text = "";
            txtEmailDG.Text = "";
            txtTimKiemDG.Text = "";
            //dtNgaySinh.Value = DateTime.Now;

            btnThemDG.Enabled = true;
            btnSuaDG.Enabled = false;
            btnXoaDG.Enabled = false;

            txtMaDG.Enabled = true;

            //Form Quản lý sách
            txtMaS.Text = "";
            txtTenSach.Text = "";
            txtNXB.Text = "";
            txtTacGia.Text = "";
            txtMaTLS.Text = "";
            txtTKS.Text = "";
            txtTinhTrangS.Text = "";
            txtGiaS.Text = "";
            txtNamXB.Text = "";

            btnThemS.Enabled = true;
            btnXoaS.Enabled = false;
            btnSuaS.Enabled = false;
            

            txtMaS.Enabled = true;
            //Form Quản lý thể loại
            txtMaTL.Text = "";
            txtTenTL.Text = "";
            txtTKTL.Text = "";

            btnThemTL.Enabled = true;
            btnXoaTL.Enabled = false;
            btnSuaTL.Enabled = false;

            txtMaTL.Enabled = true;
            //Form Quản lý phiếu mượn trả
            txtTKPMT.Text = "";
            txtMaPM.Text = "";
            txtMaDGPMT.Text = "";
            //dtNgayMuon.Value = DateTime.Now;

            btnThemPMT.Enabled = true;
            btnSuaPMT.Enabled = false;
            btnXoaPMT.Enabled = false;

            txtMaPM.Enabled = true;
            //Form Quản lý CTPMT
            txtMaCTPM.Text = "";
            txtMaSachCTPMT.Text = "";
            txtPhieuMuonCTPMT.Text = "";
            txtTienPhat.Text = "";
            txtTKCTPMT.Text = "";
            txtTinhTrangCTPMT.Text = "";
            txtGhiChu.Text = "";
            //dtNgayTra.Value = DateTime.Now;

            btnThemCTPMT.Enabled = true;
            btnSuaCTPMT.Enabled = false;
            btnXoaCTPMT.Enabled = false;

            txtMaCTPM.Enabled = true;

            //Bắt lỗi nút xóa 
            if (frmFromMain.VaiTro == "Thủ Thư")
            {
                btnXoa.Enabled = false;
                btnXoaCTPMT.Enabled = false;
                btnXoaDG.Enabled = false;
                btnXoaPMT.Enabled = false;
                btnXoaS.Enabled = false;
                btnXoaTL.Enabled = false;
            }
        }
        DataTable NhanVien;
        DataTable DoGia;
        DataTable Sach;
        DataTable TheLoai;
        DataTable PhieuMT;
        DataTable ChiTietPhieuMT;
        private void LoadDataGridViewQLTK()
        {
            string SqlString = "Select * From NhanVien";
            NhanVien = Funtions.GetDataToTable(SqlString);
            dgvTaiKhoan.DataSource = NhanVien;
        }
        private void LoadDataGridViewDG()
        {
            string SqlString = "Select * From DoGia";
            DoGia = Funtions.GetDataToTable(SqlString);
            dgvDocGia.DataSource = DoGia;
        }
        private void LoadDataGridViewS()
        {
            string SqlString = "Select * From Sach";
            Sach = Funtions.GetDataToTable(SqlString);
            dgvQLSach.DataSource = Sach;
        }
        private void LoadDataGridViewTL()
        {
            string SqlString = "Select * From TheLoai";
            TheLoai = Funtions.GetDataToTable(SqlString);
            dgvTheLoai.DataSource = TheLoai;
        }
        private void LoadDataGridViewPMT()
        {
            string SqlString = "Select * From PhieuMT";
            PhieuMT = Funtions.GetDataToTable(SqlString);
            dgvMuonTra.DataSource = PhieuMT;
        }
        private void LoadDataGridViewCTPMT()
        {
            string SqlString = "Select * From ChiTietPhieuMT";
            ChiTietPhieuMT = Funtions.GetDataToTable(SqlString);
            dgvQLCTPMT.DataSource = ChiTietPhieuMT;
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            try
            {
                DateTime dt = dtNgaySinh.Value;
                if (txtUsername.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Username", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtUsername.Focus();
                    return;
                }
                else if (txtPassword.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Password", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPassword.Focus();
                    return;
                }
                else if (txtHoTen.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập họ tên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtHoTen.Focus();
                    return;
                }
                else if (cbVaiTro.SelectedIndex == -1)
                {
                    MessageBox.Show("Vui lòng chọn vai trò", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cbVaiTro.Focus();
                    return;
                }
                else if (!CheckDate(dt))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtNgaySinh.Focus();
                    return;
                }
                else if (txtSDT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSDT.Focus();
                    return;
                }
                else if (txtDiaChi.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDiaChi.Focus();
                    return;
                }
                else if (txtEmail.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmail.Focus();
                    return;
                }
                string StrUsername = txtUsername.Text.Trim();
                string StrPassword = txtPassword.Text.Trim();
                string StrHoten = txtHoTen.Text.Trim(); ;
                string StrVaiTro = cbVaiTro.SelectedItem.ToString();
                string StrNgaySinh = dt.ToString("yyyy-MM-dd");
                string StrSDT = txtSDT.Text.Trim();
                string StrDiaChi = txtDiaChi.Text.Trim();
                string StrEmail = txtEmail.Text.Trim();

                string SqlStr = "Select Username From NhanVien Where Username = '" + StrUsername + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Username đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsername.Focus();
                    return;
                }
                SqlStr = "Insert Into NhanVien Values (N'" + StrUsername + "', N'" + StrPassword + "',N'" + StrHoten + "',N'" + StrVaiTro + "','" + StrNgaySinh + "','" + StrSDT + "','" + StrDiaChi + "','" + StrEmail + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewQLTK();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {

                DateTime dt = dtNgaySinh.Value;
                if (txtUsername.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Username", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtUsername.Focus();
                    return;
                }
                else if (txtPassword.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Password", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPassword.Focus();
                    return;
                }
                else if (txtHoTen.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập họ tên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtHoTen.Focus();
                    return;
                }
                else if (cbVaiTro.SelectedIndex == -1)
                {
                    MessageBox.Show("Vui lòng chọn vai trò", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cbVaiTro.Focus();
                    return;
                }
                else if (!CheckDate(dt))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày sinh", "Thông báo", MessageBoxButtons.OK);
                    dtNgaySinh.Focus();
                    return;
                }
                else if (txtSDT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSDT.Focus();
                    return;
                }
                else if (txtDiaChi.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDiaChi.Focus();
                    return;
                }
                else if (txtEmail.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmail.Focus();
                    return;
                }
                string StrUsername = txtUsername.Text.Trim();
                string StrPassword = txtPassword.Text.Trim();
                string StrHoten = txtHoTen.Text.Trim();
                string StrVaiTro = cbVaiTro.SelectedItem.ToString();
                string StrNgaySinh = dt.ToString("yyyy-MM-dd");
                string StrSDT = txtSDT.Text.Trim();
                string StrDiaChi = txtDiaChi.Text.Trim();
                string StrEmail = txtEmail.Text.Trim();

                string SqlStr = "Update NhanVien Set Password = '" + StrPassword + "',HoTenNV = N'" + StrHoten + "',VaiTro = N'" + StrVaiTro + "',NgaySinh = '" + StrNgaySinh + "',SDT = '" + StrSDT + "',DiaChi = N'" + StrDiaChi + "',Email = '" + StrEmail + "' Where Username = '" + StrUsername + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewQLTK();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
            Reset();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string StrUsername = txtUsername.Text.Trim();
                string SqlStr = "Select * From NhanVien Where Username = '" + StrUsername + "'";

                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    SqlStr = "Delete From NhanVien where Username = '" + StrUsername + "'";
                    SqlCommand cmd = new SqlCommand(SqlStr, Funtions.Con);
                    cmd.ExecuteNonQuery();

                    LoadDataGridViewQLTK();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex);
            }
            Reset();
        }

        private void dgvTaiKhoan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvTaiKhoan.Rows[e.RowIndex];
            txtUsername.Text = row.Cells[0].Value.ToString();
            txtPassword.Text = row.Cells[1].Value.ToString();
            txtHoTen.Text = row.Cells[2].Value.ToString();
            cbVaiTro.SelectedItem = row.Cells[3].Value.ToString();
            dtNgaySinh.Value = Convert.ToDateTime(row.Cells[4].Value.ToString());
            txtSDT.Text = row.Cells[5].Value.ToString();
            txtDiaChi.Text = row.Cells[6].Value.ToString();
            txtEmail.Text = row.Cells[7].Value.ToString();

            if (txtUsername.Text == frmFromMain.ThongTinDangNhap.TenDangNhap)
            {
                cbVaiTro.Enabled = false;
            }
            else
            {
                cbVaiTro.Enabled = true;
            }

            if (e.RowIndex != -1)
            {
                btnThem.Enabled = false;
                btnXoa.Enabled = true;
                btnSua.Enabled = true;

                txtUsername.Enabled = false;
                return;
            }
        }

        private void dgvDocGia_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvDocGia.Rows[e.RowIndex];
            txtMaDG.Text = row.Cells[0].Value.ToString();
            txtHoTenDG.Text = row.Cells[1].Value.ToString();
            dtNgaySinhDG.Value = Convert.ToDateTime(row.Cells[2].Value.ToString());
            txtSDTDG.Text = row.Cells[3].Value.ToString();
            txtDiaChiDG.Text = row.Cells[4].Value.ToString();
            txtEmailDG.Text = row.Cells[5].Value.ToString();
            if (e.RowIndex != -1)
            {
                btnThemDG.Enabled = false;
                btnSuaDG.Enabled = true;
                btnXoaDG.Enabled = true;

                txtMaDG.Enabled = false;
                return;
            }
        }

        private void dgvQLSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvQLSach.Rows[e.RowIndex];
            txtMaS.Text = row.Cells[0].Value.ToString();
            txtMaTLS.Text = row.Cells[1].Value.ToString();
            txtTenSach.Text = row.Cells[2].Value.ToString();
            txtGiaS.Text = row.Cells[3].Value.ToString();
            txtTinhTrangS.Text = row.Cells[4].Value.ToString();
            txtTacGia.Text = row.Cells[5].Value.ToString();
            txtNXB.Text = row.Cells[6].Value.ToString();
            txtNamXB.Text = row.Cells[7].Value.ToString();

            if (e.RowIndex != -1)
            {
                btnThemS.Enabled = false;
                btnXoaS.Enabled = true;
                btnSuaS.Enabled = true;

                txtMaS.Enabled = false;
            }
        }

        private void dgvTheLoai_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvTheLoai.Rows[e.RowIndex];
            txtMaTL.Text = row.Cells[0].Value.ToString();
            txtTenTL.Text = row.Cells[1].Value.ToString();
            if (e.RowIndex != -1)
            {
                btnThemTL.Enabled = false;
                btnXoaTL.Enabled = true;
                btnSuaTL.Enabled = true;

                txtMaTL.Enabled = false;
            }
        }

        private void dgvMuonTra_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvMuonTra.Rows[e.RowIndex];
            txtMaPM.Text = row.Cells[0].Value.ToString();
            txtMaDGPMT.Text = row.Cells[1].Value.ToString();
            dtNgayMuon.Value = Convert.ToDateTime(row.Cells[2].Value.ToString());
            if (e.RowIndex != -1)
            {
                btnThemPMT.Enabled = false;
                btnSuaPMT.Enabled = true;
                btnXoaPMT.Enabled = true;

                txtMaPM.Enabled = false;
            }
        }

        private void dgvQLCTPMT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }
            DataGridViewRow row = dgvQLCTPMT.Rows[e.RowIndex];
            txtMaCTPM.Text = row.Cells[0].Value.ToString();
            txtMaSachCTPMT.Text = row.Cells[1].Value.ToString();
            txtPhieuMuonCTPMT.Text = row.Cells[2].Value.ToString();
            txtTienPhat.Text = row.Cells[3].Value.ToString();
            txtGhiChu.Text = row.Cells[4].Value.ToString();
            txtTinhTrangCTPMT.Text = row.Cells[5].Value.ToString();
            dtNgayTra.Value = Convert.ToDateTime(row.Cells[6].Value.ToString());

            if (e.RowIndex != -1)
            {
                btnThemCTPMT.Enabled = false;
                btnSuaCTPMT.Enabled = true;
                btnXoaCTPMT.Enabled = true;

                txtMaCTPM.Enabled = false;
            }
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                // Nếu là ký số, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
            else if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                // Nếu là ký tự đặc biệt, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
        }

        private void txtHoTen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                // Nếu là Handle ký số, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
            // Kiểm tra xem ký tự nhập vào có phải là chữ cái, số, hoặc khoảng trắng không            
            else if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                // Nếu là ký tự đặc biệt, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
        }

        private void txtSDT_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Kiểm tra xem ký tự là số và là ký tự số từ 0 đến 9
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ngăn chặn ký tự không hợp lệ từ được nhập
            }

            // Kiểm tra độ dài của chuỗi để đảm bảo không vượt quá 10 ký tự
            if ((sender as TextBox).Text.Length >= 10 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Ngăn chặn thêm ký tự khi đã đạt tới giới hạn 10 ký tự
            }
        }

        private void frmQuanLy_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmFromMain main = new frmFromMain();
            main.Show();
            this.Hide();
        }

        private void btnThemDG_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dtdg = dtNgaySinhDG.Value;
                if (txtMaDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaDG.Focus();
                    return;
                }
                else if (txtHoTenDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập họ tên độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtHoTenDG.Focus();
                    return;
                }
                else if (!CheckDate(dtdg))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtNgaySinhDG.Focus();
                    return;
                }
                else if (txtEmailDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmailDG.Focus();
                    return;
                }
                else if (txtDiaChiDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDiaChiDG.Focus();
                    return;
                }
                else if (txtSDTDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSDTDG.Focus();
                    return;
                }

                string StrMaDG = txtMaDG.Text.Trim();
                string StrHoTenDG = txtHoTenDG.Text.Trim();
                string StrNgaySinhDG = dtdg.ToString("yyyy-MM-dd");
                string StrSDTDG = txtSDTDG.Text.Trim();
                string StrDiaChiDG = txtDiaChiDG.Text.Trim();
                string StrEmailDG = txtEmailDG.Text.Trim();

                string SqlStr = "Select MaDG From DoGia Where MaDG = '" + StrMaDG + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Mã độc giả  đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDG.Focus();
                    return;
                }
                SqlStr = "Insert Into DoGia Values (N'" + StrMaDG + "', N'" + StrHoTenDG + "',N'" + StrNgaySinhDG + "',N'" + StrSDTDG + "',N'" + StrDiaChiDG + "','" + StrEmailDG + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewDG();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnSuaDG_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dtdg = dtNgaySinhDG.Value;
                if (txtMaDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaDG.Focus();
                    return;
                }
                else if (txtHoTenDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập họ tên độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtHoTenDG.Focus();
                    return;
                }
                else if (!CheckDate(dtdg))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtNgaySinhDG.Focus();
                    return;
                }
                else if (txtEmailDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập email", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmailDG.Focus();
                    return;
                }
                else if (txtDiaChiDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDiaChiDG.Focus();
                    return;
                }
                else if (txtSDTDG.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSDTDG.Focus();
                    return;
                }

                string StrMaDG = txtMaDG.Text.Trim();
                string StrHoTenDG = txtHoTenDG.Text.Trim();
                string StrNgaySinhDG = dtdg.ToString("yyyy-MM-dd");
                string StrSDT = txtSDTDG.Text.Trim();
                string StrDiaChi = txtDiaChiDG.Text.Trim();
                string StrEmail = txtEmailDG.Text.Trim();

                string SqlStr = "Update DoGia Set HoTenDG = N'" + StrHoTenDG + "', NgaySinh = N'" + StrNgaySinhDG + "',SDT = N'" + StrSDT + "',DiaChi = N'" + StrDiaChi + "',Email = '" + StrEmail + "'Where MaDG = N'" + StrMaDG + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewDG();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnXoaDG_Click(object sender, EventArgs e)
        {
            try
            {
                string StrMaDG = txtMaDG.Text.Trim();
                string SqlStr = "Select * From DoGia Where MaDG = '" + StrMaDG + "'";

                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string SqlStrCheck = "SELECT COUNT(*) FROM PhieuMT WHERE MaDGPMT = '" + StrMaDG + "'";
                int count = (int)new SqlCommand(SqlStrCheck, Funtions.Con).ExecuteScalar();

                if (count > 0)
                {
                    // Nếu có dữ liệu liên kết, hiển thị thông báo và không thực hiện xóa
                    MessageBox.Show("Không thể xóa độc giả này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        SqlStr = "Delete From DoGia where MaDG = '" + StrMaDG + "'";
                        SqlCommand cmd = new SqlCommand(SqlStr, Funtions.Con);
                        cmd.ExecuteNonQuery();

                        LoadDataGridViewDG();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex);
            }
            Reset();
        }

        private void btnTimKiemDG_Click(object sender, EventArgs e)
        {
            try
            {
                string TenDG = txtTimKiemDG.Text.Trim();
                string SqlStr = "Select * From DoGia Where HoTenDG Like N'%" + TenDG + "%'";
                SqlDataAdapter dap = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                dgvDocGia.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            Reset();
        }

        private void txtHoTenDG_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                // Nếu là ký số, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
            // Kiểm tra xem ký tự nhập vào có phải là chữ cái, số, hoặc khoảng trắng không            
            else if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                // Nếu là ký tự đặc biệt, ngăn chặn ký tự nhập vào
                e.Handled = true;
            }
        }

        private void txtSDTDG_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Kiểm tra xem ký tự là số và là ký tự số từ 0 đến 9
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ngăn chặn ký tự không hợp lệ từ được nhập
            }

            // Kiểm tra độ dài của chuỗi để đảm bảo không vượt quá 10 ký tự
            if ((sender as TextBox).Text.Length >= 10 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Ngăn chặn thêm ký tự khi đã đạt tới giới hạn 10 ký tự
            }
        }

        private void btnThemS_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMaS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaS.Focus();
                    return;
                }
                else if (txtMaTLS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã thể loại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaTLS.Focus();
                    return;
                }
                else if (txtTenSach.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tên sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenSach.Focus();
                    return;
                }
                else if (txtGiaS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGiaS.Focus();
                    return;
                }
                else if (txtTinhTrangS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tình trạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTinhTrangS.Focus();
                    return;
                }
                else if (txtTacGia.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tác giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTacGia.Focus();
                    return;
                }
                else if (txtNXB.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập NXB", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNXB.Focus();
                    return;
                }
                else if (txtNamXB.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập Năm XB", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNamXB.Focus();
                    return;
                }

                string StrMaSach = txtMaS.Text.Trim();
                string StrMaTL = txtMaTLS.Text.Trim();
                string StrTenSach = txtTenSach.Text.Trim();
                string StrGia = txtGiaS.Text.Trim();
                string StrTinhTrang = txtTinhTrangS.Text.Trim();
                string StrTacGia = txtTacGia.Text.Trim();
                string StrNXB = txtNXB.Text.Trim();
                string StrNamXB = txtNamXB.Text.Trim();

                string SqlStr = "Select MaSach From Sach Where MaSach = '" + StrMaSach + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Mã sách đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaS.Focus();
                    return;
                }
                SqlStr = "Select * From TheLoai Where MaTL = '" + StrMaTL + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã thể loại này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaTL.Focus();
                    return;
                }
                SqlStr = "Insert Into Sach Values (N'" + StrMaSach + "', N'" + StrMaTL + "',N'" + StrTenSach + "','" + StrGia + "',N'" + StrTinhTrang + "',N'" + StrTacGia + "',N'" + StrNXB + "','" + StrNamXB + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewS();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnSuaS_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMaS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaS.Focus();
                    return;
                }
                else if (txtMaTLS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã thể loại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaTLS.Focus();
                    return;
                }
                else if (txtTenSach.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tên sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenSach.Focus();
                    return;
                }
                else if (txtGiaS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGiaS.Focus();
                    return;
                }
                else if (txtTinhTrangS.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tình trạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTinhTrangS.Focus();
                    return;
                }
                else if (txtTacGia.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tác giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTacGia.Focus();
                    return;
                }
                else if (txtNXB.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập NXB", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNXB.Focus();
                    return;
                }
                else if (txtNamXB.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng kiểm tra lại năm XB", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNamXB.Focus();
                    return;
                }

                string StrMaSach = txtMaS.Text.Trim();
                string StrMaTL = txtMaTLS.Text.Trim();
                string StrTenSach = txtTenSach.Text.Trim();
                string StrGia = txtGiaS.Text.Trim();
                string StrTinhTrang = txtTinhTrangS.Text.Trim();
                string StrTacGia = txtTacGia.Text.Trim();
                string StrNXB = txtNXB.Text.Trim();
                string StrNamXB = txtNamXB.Text.Trim();

                string SqlStr = "Select * From TheLoai Where MaTL = '" + StrMaTL + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã thể loại này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaTL.Focus();
                    return;
                }
                SqlStr = "Update Sach Set MaTLS = N'" + StrMaTL + "',TenSach = N'" + StrTenSach + "',Gia = '" + StrGia + "',TinhTrang = N'" + StrTinhTrang + "',TacGia = N'" + StrTacGia + "',NXB = N'" + StrNXB + "',NamXB = '" + StrNamXB + "'Where MaSach = N'" + StrMaSach + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewS();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);

            }
        }

        private void btnXoaS_Click(object sender, EventArgs e)
        {
            try
            {
                string StrMaSach = txtMaS.Text.Trim();

                string SqlStr = "Select * From Sach Where MaSach = '" + StrMaSach + "'";
                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string SqlStrMS = "SELECT COUNT(*) FROM ChiTietPhieuMT WHERE MaSachCTPMT = '" + StrMaSach + "'";
                int count = (int)new SqlCommand(SqlStrMS, Funtions.Con).ExecuteScalar();
                if (count > 0)
                {
                    // Nếu có dữ liệu liên kết, hiển thị thông báo và không thực hiện xóa
                    MessageBox.Show("Không thể xóa sách này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    SqlStr = "Delete From Sach Where MaSach = N'" + StrMaSach + "'";
                    Funtions.RunSQL(SqlStr);
                    LoadDataGridViewS();
                    Reset();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnTKS_Click(object sender, EventArgs e)
        {
            try
            {
                string TenSach = txtTKS.Text.Trim();
                string SqlStr = "Select * From Sach Where TenSach Like N'%" + TenSach + "%'";
                SqlDataAdapter dap = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                dgvQLSach.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            Reset();
        }

        private void txtGiaS_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Kiểm tra xem ký tự là số hoặc là dấu chấm thập phân
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true; // Ngăn chặn ký tự không hợp lệ từ được nhập
            }

            // Chỉ cho phép một dấu chấm thập phân
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void btnThemTL_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMaTL.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Mã thể loại không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaTL.Focus();
                    return;
                }
                else if (txtTenTL.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Tên thể loại không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenTL.Focus();
                    return;
                }
                string StrMaTL = txtMaTL.Text.Trim();
                string StrTenTL = txtTenTL.Text.Trim();

                string SqlStr = "Select MaTL From TheLoai Where MaTL = '" + StrMaTL + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Mã thể loại đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaTL.Focus();
                    return;
                }
                SqlStr = "Insert Into TheLoai Values (N'" + StrMaTL + "', N'" + StrTenTL + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewTL();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnSuaTL_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMaTL.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Mã thể loại không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaTL.Focus();
                    return;
                }
                else if (txtTenTL.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Tên thể loại không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenTL.Focus();
                    return;
                }
                string StrMaTL = txtMaTL.Text.Trim();
                string StrTenTL = txtTenTL.Text.Trim();

                string SqlStr = "Update TheLoai Set TenTL = N'" + StrTenTL + "' Where MaTL = '" + StrMaTL + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewTL();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnXoaTL_Click(object sender, EventArgs e)
        {
            try
            {
                string StrMaTL = txtMaTL.Text.Trim();

                string SqlStr = "Select * From TheLoai Where MaTL = '" + StrMaTL + "'";
                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string StrMaTLS = txtMaTL.Text.Trim();
                string SqlStrMS = "SELECT COUNT(*) FROM Sach WHERE MaTLS = '" + StrMaTLS + "'";
                int count = (int)new SqlCommand(SqlStrMS, Funtions.Con).ExecuteScalar();

                if (count > 0)
                {
                    // Nếu có dữ liệu liên kết, hiển thị thông báo và không thực hiện xóa
                    MessageBox.Show("Không thể xóa MaTL này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        SqlStr = "Delete From TheLoai Where MaTL = N'" + StrMaTL + "'";
                        Funtions.RunSQL(SqlStr);
                        LoadDataGridViewTL();
                        Reset();
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnTKTL_Click(object sender, EventArgs e)
        {
            try
            {
                string StrTenTL = txtTKTL.Text.Trim();
                string SqlStr = "Select * From TheLoai Where TenTL Like N'%" + StrTenTL + "%'";
                SqlDataAdapter dap = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                 dgvTheLoai.DataSource = dt;
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            
        }

        private void btnThemPMT_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dt = dtNgayMuon.Value;
                if (txtMaPM.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaPM.Focus();
                    return;
                }
                else if (txtMaDGPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaDG.Focus();
                    return;
                }
                else if (!CheckDate(dt))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtNgayMuon.Focus();
                    return;
                }
                
                string StrMaPM = txtMaPM.Text.Trim();
                string StrMaDG = txtMaDGPMT.Text.Trim();
                string StrNgayMuon = dt.ToString("yyyy-MM-dd");

                string SqlStr = "Select MaPM From PhieuMT Where MaPM = '" + StrMaPM + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Mã phiếu mượn đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaPM.Focus();
                    return;
                }
                SqlStr = "Select * From DoGia Where MaDG = '" + StrMaDG + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã độc giả này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDG.Focus();
                    return;
                }
                SqlStr = "Insert Into PhieuMT Values (N'" + StrMaPM + "', N'" + StrMaDG + "', '" + StrNgayMuon + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewPMT();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }
        // Hàm để truy xuất ngày trả từ cơ sở dữ liệu
        private DateTime GetNgayTraFromDatabase(string maPM)
        {
            string sqlStr = "SELECT NgayTra FROM ChiTietPhieuMT WHERE MaCTPMT = '" + maPM + "'";
            object result = Funtions.GetField(sqlStr);

            if (result != null && result != DBNull.Value)
            {
                return Convert.ToDateTime(result);
            }

            // Nếu không có ngày trả, trả về ngày mặc định hoặc giá trị khác tùy theo yêu cầu của bạn.
            return DateTime.MinValue;
        }
        private DateTime GetNgayMuonFromDatabase(string maPM)
        {
            string sqlStr = "SELECT NgayMuon FROM PhieuMT WHERE MaPM = '" + maPM + "'";
            object result = Funtions.GetField(sqlStr);

            if (result != null && result != DBNull.Value)
            {
                return Convert.ToDateTime(result);
            }

            // Nếu không có ngày trả, trả về ngày mặc định hoặc giá trị khác tùy theo yêu cầu của bạn.
            return DateTime.MinValue;
        }
        private void btnSuaPMT_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dt = dtNgayMuon.Value;
               
                if (txtMaPM.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaPM.Focus();
                    return;
                }
                else if (txtMaDGPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã độc giả", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaDG.Focus();
                    return;
                }
                else if (!CheckDate(dt))
                {
                    MessageBox.Show("Vui lòng kiểm tra lại ngày mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dtNgayMuon.Focus();
                    return;
                }
                // Lấy ngày trả từ cơ sở dữ liệu cho phiếu mượn đang được sửa
                DateTime ngayTraFromDB = GetNgayTraFromDatabase(txtMaCTPM.Text.Trim());
                if (dt < ngayTraFromDB)
                {
                    MessageBox.Show("Ngày mượn không thể lớn hơn ngày trả. Vui lòng kiểm tra lại." + dt + ";" + ngayTraFromDB + "", "Lỗi Ngày Mượn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string StrMaPM = txtMaPM.Text.Trim();
                string StrMaDG = txtMaDGPMT.Text.Trim();
                string StrNgayMuon = dt.ToString("yyyy-MM-dd");
                
                string SqlStr = "Select * From DoGia Where MaDG = '" + StrMaDG + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã độc giả này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaDG.Focus();
                    return;
                }
                SqlStr = "Update PhieuMT Set MaDGPMT = N'" + StrMaDG + "',NgayMuon = '" + StrNgayMuon + "'Where MaPM = N'" + StrMaPM + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewPMT();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnXoaPMT_Click(object sender, EventArgs e)
        {
            try
            {
                string StrMaPM = txtMaPM.Text.Trim();

                string SqlStr = "Select * From PhieuMT Where MaPM = '" + StrMaPM + "'";
                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string SqlStrMPM = "SELECT COUNT(*) FROM ChiTietPhieuMT WHERE MaPMCTPMT = '" + StrMaPM + "'";
                int countmpm = (int)new SqlCommand(SqlStrMPM, Funtions.Con).ExecuteScalar();
                if (countmpm > 0)
                {
                    MessageBox.Show("Không thể xóa phiếu mượn này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    SqlStr = "Delete From PhieuMT Where MaPM = N'" + StrMaPM + "'";
                    Funtions.RunSQL(SqlStr);
                    LoadDataGridViewPMT();
                    Reset();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnTKPMT_Click(object sender, EventArgs e)
        {
            try
            {
                string MaDG = txtTKPMT.Text.Trim();
                string SqlStr = "Select * From PhieuMT Where MaDGPMT Like N'%" + MaDG + "%'";
                SqlDataAdapter dap = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                dgvMuonTra.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            Reset();
        }

        private void btnThemCTPMT_Click(object sender, EventArgs e)
        {
            try
            {                
                DateTime dt = dtNgayTra.Value;
                if (txtMaCTPM.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã chi tiết phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaCTPM.Focus();
                    return;
                }
                else if (txtMaSachCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaSachCTPMT.Focus();
                    return;
                }
                else if (txtPhieuMuonCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPhieuMuonCTPMT.Focus();
                    return;
                }
                else if (txtTienPhat.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tiền phạt", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTienPhat.Focus();
                    return;
                }
                else if (txtGhiChu.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập ghi chú", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGhiChu.Focus();
                    return;
                }
                else if (txtTinhTrangCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tình trạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTinhTrangCTPMT.Focus();
                    return;
                }
                // Lấy ngày trả từ cơ sở dữ liệu cho phiếu mượn đang được sửa
                DateTime ngayMuonFromDB = GetNgayMuonFromDatabase(txtPhieuMuonCTPMT.Text.Trim());
                if (dt < ngayMuonFromDB)
                {
                    MessageBox.Show("Ngày mượn không thể lớn hơn ngày trả. Vui lòng kiểm tra lại." + dt + ";" + ngayMuonFromDB + "", "Lỗi Ngày Mượn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string StrMaCTPM = txtMaCTPM.Text.Trim();
                string StrMaSach = txtMaSachCTPMT.Text.Trim();
                string StrMaPM = txtPhieuMuonCTPMT.Text.Trim();
                string StrTienPhat = txtTienPhat.Text.Trim();
                string StrGhiChu = txtGhiChu.Text.Trim();
                string StrTinhTrang = txtTinhTrangCTPMT.Text.Trim();
                string StrNgayTra = dt.ToString("yyyy-MM-dd");

                string SqlStr = "Select MaCTPMT From ChiTietPhieuMT Where MaCTPMT = '" + StrMaCTPM + "'";
                if (Funtions.CheckPK(SqlStr))
                {
                    MessageBox.Show("Mã chi tiết phiếu mượn đã có", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaCTPM.Focus();
                    return;
                }
                SqlStr = "Select * From Sach Where MaSach = '" + StrMaSach + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã sách này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaS.Focus();
                    return;
                }
                SqlStr = "Select * From PhieuMT Where MaPM = '" + StrMaPM + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã phiếu mượn này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaPM.Focus();
                    return;
                }
                SqlStr = "Insert Into ChiTietPhieuMT Values (N'" + StrMaCTPM + "', N'" + StrMaSach + "',N'" + StrMaPM + "','" + StrTienPhat + "',N'" + StrGhiChu + "',N'" + StrTinhTrang + "','" + StrNgayTra + "')";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewCTPMT();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnSuaCTPMT_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dt = dtNgayTra.Value;
                if (txtMaCTPM.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã chi tiết phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaCTPM.Focus();
                    return;
                }
                else if (txtGhiChu.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập ghi chú", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtGhiChu.Focus();
                    return;
                }
                else if (txtPhieuMuonCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã phiếu mượn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtPhieuMuonCTPMT.Focus();
                    return;
                }
                else if (txtMaSachCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập mã sách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMaSachCTPMT.Focus();
                    return;
                }
                else if (txtTienPhat.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập số tiền phạt", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTienPhat.Focus();
                    return;
                }
                else if (txtTinhTrangCTPMT.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Vui lòng nhập tình trạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTinhTrangCTPMT.Focus();
                    return;
                }
                // Lấy ngày trả từ cơ sở dữ liệu cho phiếu mượn đang được sửa
                DateTime ngayMuonFromDB = GetNgayMuonFromDatabase(txtPhieuMuonCTPMT.Text.Trim());
                if (dt < ngayMuonFromDB)
                {
                    MessageBox.Show("Ngày mượn không thể lớn hơn ngày trả. Vui lòng kiểm tra lại." + dt + ";" + ngayMuonFromDB + "", "Lỗi Ngày Mượn", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string StrGhiChu = txtGhiChu.Text.Trim();
                string StrMaCTPM = txtMaCTPM.Text.Trim();
                string StrMaPM = txtPhieuMuonCTPMT.Text.Trim(); ;
                string StrMaSach = txtMaSachCTPMT.Text.Trim();
                string StrNgayTra = dt.ToString("yyyy-MM-dd");
                string StrTienPhat = txtTienPhat.Text.Trim();
                string StrTinhTrang = txtTinhTrangCTPMT.Text.Trim();
                string SqlStr = "Select * From Sach Where MaSach = '" + StrMaSach + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã sách này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaS.Focus();
                    return;
                }
                SqlStr = "Select * From PhieuMT Where MaPM = '" + StrMaPM + "'";
                if (Funtions.CheckRecord(SqlStr) == false)
                {
                    MessageBox.Show("Chưa có mã phiếu mượn này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaPM.Focus();
                    return;
                }
                SqlStr = "Update ChiTietPhieuMT Set MaSachCTPMT = N'" + StrMaSach + "',MaPMCTPMT = N'" + StrMaPM + "',TienPhat = '" + StrTienPhat + "',GhiChu = N'" + StrGhiChu + "',TinhTrang = N'" + StrTinhTrang + "',NgayTra = '" + StrNgayTra + "'Where MaCTPMT = '" + StrMaCTPM + "'";
                Funtions.RunSQL(SqlStr);
                LoadDataGridViewCTPMT();
                Reset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Báo lỗi", MessageBoxButtons.OK);
            }
        }

        private void btnXoaCTPMT_Click(object sender, EventArgs e)
        {
            try
            {
                string StrMaCTPMT = txtMaCTPM.Text.Trim();
                string SqlStr = "Select * From ChiTietPhieuMT Where MaCTPMT = '" + StrMaCTPMT + "'";

                SqlDataAdapter sda = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }                            
                else
                {
                    DialogResult result = MessageBox.Show("Bạn có chắc xóa không?", "Thông báo", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        SqlStr = "Delete From ChiTietPhieuMT where MaCTPMT = '" + StrMaCTPMT + "'";
                        SqlCommand cmd = new SqlCommand(SqlStr, Funtions.Con);
                        cmd.ExecuteNonQuery();

                        LoadDataGridViewCTPMT();
                    }
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex);
            }
            Reset();
        }

        private void btnTKCTPMT_Click(object sender, EventArgs e)
        {
            try
            {
                string MaCTPM = txtTKCTPMT.Text.Trim();
                string SqlStr = "Select * From ChiTietPhieuMT Where MaCTPMT Like N'%" + MaCTPM + "%'";
                SqlDataAdapter dap = new SqlDataAdapter(SqlStr, Funtions.Con);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                dgvQLCTPMT.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            Reset();
        }

        private void txtTienPhat_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Kiểm tra xem ký tự là số hoặc là dấu chấm thập phân
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true; // Ngăn chặn ký tự không hợp lệ từ được nhập
            }

            // Chỉ cho phép một dấu chấm thập phân
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

    }
}
